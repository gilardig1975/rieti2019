package it.sistinf.wave3.batch.kafka.impl;

import java.io.IOException;
import java.util.Date;

import javax.enterprise.context.Dependent;
import javax.inject.Named;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import it.sistinf.wave3.batch.kafka.AbstractConsumerBatchlet;
import it.sistinf.wave3.jpa.entity.SampleTable;
import it.sistinf.wave3.rest.dto.PigioRequestDTO;

@Named
@Dependent
public class SampleTableWriterBatchlet extends AbstractConsumerBatchlet<String> {

	private static final ObjectMapper MAPPER = new ObjectMapper();

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@PersistenceContext(unitName = "SampleWeb")
	private EntityManager em;

	public SampleTableWriterBatchlet() {
	}

	@Override
	protected String getValueDeserializer() {
		return StringDeserializer.class.getName();
	}

	@Override
	protected String getValueSerializer() {
		return StringSerializer.class.getName();
	}

	@Override
	protected int process(KafkaConsumer<String, String> consumer, ConsumerRecords<String, String> records) {

		int count = 0;
		UserTransaction ut = null;
		try {
			ut = (UserTransaction) new InitialContext().lookup("java:comp/UserTransaction");
			ut.begin();

			for (ConsumerRecord<String, String> consumerRecord : records) {
				String msg = consumerRecord.value();
				try {
					PigioRequestDTO dto = MAPPER.readValue(msg, PigioRequestDTO.class);
					SampleTable st = new SampleTable();
					st.setId(dto.getId());
					st.setValue(dto.getValue());
					em.persist(st);
					logger.info("dto {}, em {}", dto, em);
				} catch (RuntimeException | IOException e) {

					count++;
					logger.error("unable to deserialize message {} - {} - {} - {} - {} - {}", consumerRecord.topic(),
							consumerRecord.partition(), consumerRecord.offset(), new Date(consumerRecord.timestamp()),
							consumerRecord.key(), msg);
				}
			}
			ut.commit();
		} catch (Exception e) {
			logger.error("error on ut", e);
		}
		return count;
	}

}
