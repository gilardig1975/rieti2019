package it.sistinf.wave3.batch.kafka;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import javax.batch.api.AbstractBatchlet;
import javax.batch.runtime.context.JobContext;
import javax.inject.Inject;

import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This simple batchlet sleeps in 1 second increments up to
 * "sleep.time.seconds". sleep.time.seconds can be configured as a batch
 * property. If not configured, the default is 15 seconds.
 *
 */
public abstract class AbstractConsumerBatchlet<V> extends AbstractBatchlet implements ConsumerRebalanceListener {

	public static final String DEFAULT_POLLING_TIME = "20000";
	public static final String SOURCE_TOPIC = "topic.name";
	public static final String POLLING_TIME = "polling.time";

	private final Logger logger = LoggerFactory.getLogger(getClass());
	private KafkaConsumer<String, V> kafkaConsumer;
	private volatile boolean closing = false;

	@Inject
	private JobContext jobContext;

	protected Properties consumerProperties;
	private String sourceTopic;
	private long pollingTime;
	private String batchId;
//	private String handlerKey;

	@Override
	public String process() throws Exception {

		if (logger.isInfoEnabled()) {
			logger.info("batch starting");
		}

		String exitStatus = "";

		try {
			consumerProperties = jobContext.getProperties();
			consumerProperties.setProperty("value.deserializer", getValueDeserializer());
			consumerProperties.setProperty("value.serializer", getValueSerializer());

			pollingTime = Long.valueOf(consumerProperties.getProperty(POLLING_TIME, DEFAULT_POLLING_TIME));

			sourceTopic = consumerProperties.getProperty(SOURCE_TOPIC);
			logMessagePrefix = "[" + sourceTopic + "]";
			batchId = String.valueOf(jobContext.getExecutionId());

			kafkaConsumer = new KafkaConsumer<String, V>(consumerProperties);

			List<PartitionInfo> partitions = kafkaConsumer.partitionsFor(sourceTopic);

			if (logger.isInfoEnabled())
				logger.info("{} found partition {}", logMessagePrefix, partitions);

			if (partitions == null || partitions.isEmpty()) {
				String err = new StringBuffer().append(logMessagePrefix).append(" topic ")
						.append(" does not exists - application will terminate").toString();
				logger.error(err);
				kafkaConsumer.close();
				throw new IllegalStateException(err);
			}

			kafkaConsumer.subscribe(Arrays.asList(sourceTopic), this);

			if (logger.isInfoEnabled())
				logger.info("{} BatchId {} started", logMessagePrefix, batchId);

			while (!closing) {
				try {
					ConsumerRecords<String, V> records = kafkaConsumer.poll(pollingTime);
					if (records.isEmpty()) {
						if (logger.isDebugEnabled())
							logger.debug("{} No messages consumed by batchId {} on partitions {}", logMessagePrefix,
									batchId, records.partitions());
					} else {
						int totalCount = records.count();
						if (logger.isDebugEnabled()) {
							logger.debug("{} Try to consume message - partition '{}'", logMessagePrefix,
									records.partitions());
							logger.debug("{} MESSAGE_HUB_DEBUG - consuming {} records", logMessagePrefix, totalCount);
						}

						int errorCount = process(kafkaConsumer, records);

						// int messageHandler.process(records);
						if (logger.isDebugEnabled()) {
							logger.debug("{} MESSAGE_HUB_DEBUG - fetched: {}, consumed: {}, errors: {}",
									logMessagePrefix, totalCount, (totalCount - errorCount), errorCount);
						}

						kafkaConsumer.commitSync();

						if (logger.isInfoEnabled()) {
							logger.debug("{} MESSAGE_HUB_DEBUG - committed {} record(s)", logMessagePrefix, totalCount);
						}
					}

				} catch (final WakeupException e) {
					if (logger.isInfoEnabled())
						logger.info("{} Consumer closing", logMessagePrefix);
					closing = true;
				} catch (final KafkaException e) {
					logger.error("{} Sleeping for 5s - Consumer has caught: {}", logMessagePrefix, e.toString());
					// if (logger.isDebugEnabled())
					logger.error(e.toString(), e);
					try {
						Thread.sleep(5000); // Longer sleep before retrying
					} catch (InterruptedException e1) {
						logger.error("{} Consumer closing - caught exception: ", logMessagePrefix, e.getMessage());
						if (logger.isDebugEnabled())
							logger.error(e.toString(), e);
						closing = true;
					}
				}
			}
		} catch (Exception e) {
			logger.error("{} ERROR: ", logMessagePrefix, e);
		} finally {

			kafkaConsumer.close();
			if (logger.isInfoEnabled())
				logger.info("{} Consumer has shut down.", logMessagePrefix, AbstractConsumerBatchlet.class.toString());
		}

		return exitStatus;

	}

	/**
	 * org.apache.kafka.common.serialization.ByteArrayDeserializer
	 * org.apache.kafka.common.serialization.StringDeserializer ...
	 */
	protected abstract String getValueDeserializer();

	protected abstract String getValueSerializer();

	protected abstract int process(KafkaConsumer<String, V> consumer, ConsumerRecords<String, V> records);

	/**
	 * Called if the batchlet is stopped by the container.
	 */
	@Override
	public void stop() {
		closing = true;
		kafkaConsumer.wakeup();
		logger.info(AbstractConsumerBatchlet.class.toString() + " is shutting down.");
	}

	private String logMessagePrefix;

	@Override
	public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
		if (logger.isInfoEnabled())
			logger.info("{} Partitions revoked: {}", logMessagePrefix, partitions);
	}

	@Override
	public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
		if (logger.isInfoEnabled())
			logger.info("{} Partitions assigned: {}", logMessagePrefix, partitions);
	}

}
