package it.sistinf.wave3.rest.dto;

import java.util.Date;

public class PigioResponseDTO
{

	private long id;

	private String value;

	private Date date;

	public PigioResponseDTO()
	{
	}

	public long getId()
	{
		return this.id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	public String getValue()
	{
		return this.value;
	}

	public void setValue(String value)
	{
		this.value = value;
	}

	public Date getDate()
	{
		return date;
	}

	public void setDate(Date date)
	{
		this.date = date;
	}

}