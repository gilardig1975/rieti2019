package it.sistinf.wave3.jpa.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


/**
 * The persistent class for the SAMPLE_TABLE database table.
 * 
 */
@Entity
@Table(name="SAMPLE_TABLE")
@NamedQuery(name="SampleTable.findAll", query="SELECT s FROM SampleTable s")
public class SampleTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"ID\"")
	private long id;

	@Column(name="\"VALUE\"")
	private String value;

	private transient Date date;
	
	public SampleTable() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Date getDate()
	{
		return date;
	}

	public void setDate(Date date)
	{
		this.date = date;
	}

}