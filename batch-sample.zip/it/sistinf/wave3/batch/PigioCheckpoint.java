package it.sistinf.wave3.batch;

import java.io.Serializable;

public class PigioCheckpoint implements Serializable {

	private long lineNum = 0;

	public void increase() {
		lineNum++;
	}

	public long getLineNum() {
		return lineNum;
	}
}