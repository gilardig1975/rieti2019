package it.sistinf.wave3.batch;

import javax.enterprise.context.Dependent;
import javax.inject.Named;

@Dependent
@Named("PigioProcessor")
public class PigioProcessor implements javax.batch.api.chunk.ItemProcessor {
	public PigioProcessor() {
	}

	@Override
	public Object processItem(Object obj) throws Exception {
		String line = (String) obj;
		System.out.println(line);
		return line.toUpperCase();
	}
}