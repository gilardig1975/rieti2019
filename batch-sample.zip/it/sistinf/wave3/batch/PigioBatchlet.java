package it.sistinf.wave3.batch;

import java.io.File;

import javax.batch.runtime.context.JobContext;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.inject.Named;

@Dependent
@Named("PigioBatchlet")
public class PigioBatchlet implements javax.batch.api.Batchlet {
	@Inject
	private JobContext jobCtx;

	@Override
	public String process() throws Exception {
		String fileName = jobCtx.getProperties().getProperty("output_file");
		System.out.println("COMPLETED - " + (new File(fileName)).length());
		return "COMPLETED";
	}

	@Override
	public void stop() throws Exception {
				
	}
}